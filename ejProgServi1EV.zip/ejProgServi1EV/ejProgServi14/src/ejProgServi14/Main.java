package ejProgServi14;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime el valor del radio de la circunferencia");
		int radio = teclado.nextInt();
		
		double diametro = 2*radio;
		double area = 3.145 * (radio * radio);
		
		System.out.println("Diametro " + diametro + " area " + area);

	}

}
