package ejProgServi24;

import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int numero = 0;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce un numero entre el 1 y el 10");
		numero = teclado.nextInt();
		
		if (numero >= 1 && numero <= 10) {
			
			 Random random = new Random();
	            int numeroAleatorio = random.nextInt(10) + 1;
	            
	            System.out.println("Numero introducido: " + numero + " Numero aleatorio: "+ numeroAleatorio);
	            
	            if (numero == numeroAleatorio) {
	            	
	            	
	            	System.out.println("Has ganado");
	            	System.out.println("Puedes elegir tu premio:");
	            	System.out.println("Televisión");
	            	System.out.println("Móvil");
	            }else {
	            	System.out.println("Has perdido");
	            }
		}

	}

}
