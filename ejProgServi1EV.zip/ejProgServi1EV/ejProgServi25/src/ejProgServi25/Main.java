package ejProgServi25;

import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int numero1 = 0;
		int numero2 = 0;
		int numero3 = 0;
		Scanner teclado = new Scanner(System.in);
		
		
		int[] numeros = new int[3];
		
		
		for(int i = 0; i < numeros.length; i++) {
			
			System.out.println("Introduce un primer numero entre el 1 y el 10");
			numeros[i] = teclado.nextInt();
			
		}
		
		for (int i = 0; i < numeros.length; i++) {
			
			if(numeros[i] >=1 && numeros[i] <= 10) {
				
				Random random = new Random();
	            int numeroAleatorio = random.nextInt(10) + 1;
	            
	            System.out.println("Numeros introducidos: " + numeros[i] + " Numero aleatorio: "+ numeroAleatorio);
				
	            if (numeros[i] == numeroAleatorio) {
	            	
	            	
	            	System.out.println("Has ganado");
	            	System.out.println("Puedes elegir tu premio:");
	            	System.out.println("Televisión");
	            	System.out.println("Móvil");
	            }else {
	            	System.out.println("Has perdido");
	            }
			}
		}
	}

}
