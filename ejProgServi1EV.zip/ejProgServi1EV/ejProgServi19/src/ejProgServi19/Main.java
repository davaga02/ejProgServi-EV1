package ejProgServi19;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Código ASCII y su carácter correspondiente:");

        // Recorrer los códigos ASCII del 0 al 127
		
        for (int i = 0; i < 128; i++) {
        	
            // Mostrar el código y su carácter correspondiente
        	
            System.out.println("Código: " + i + " Carácter: " + (char) i);
        }
	}

}
