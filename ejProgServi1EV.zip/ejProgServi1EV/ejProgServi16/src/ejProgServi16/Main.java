package ejProgServi16;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int suma = 0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introdyce tu fecha de nacimiento:");

		System.out.println("Dime el dia:");
		int dia = teclado.nextInt();
		
		System.out.println("Dime el mes:");
		int mes = teclado.nextInt();
		
		System.out.println("Dime el año:");
		int anio = teclado.nextInt();
		
		suma = dia + mes + anio;
		
		do {
			
			suma = suma / 10 + suma%10;
			
		}while(suma > 9);

		System.out.println("Tu numero de la suerte es " + suma);
	}

}
