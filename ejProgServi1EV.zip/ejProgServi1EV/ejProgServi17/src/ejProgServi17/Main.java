package ejProgServi17;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

		
		Scanner teclado = new Scanner (System.in);
		System.out.println("Introduce una contraeña con estas caracteristicas: minimo 5 carácteres, 1 número y 1 letra mayúscula ");
		String contr = teclado.next();
		
		
		
		if(contr.length() < 5 ) {
			
			System.out.println("Error, tiene que tener como minimo 5 carácteres");
		}
		
		if (contr.length() >= 5) {
			
			boolean mayuscula = false;
			boolean numero = false;
			
			char contar;
			
			for (int i = 0; i < contr.length(); i++) {
				
				contar = contr.charAt(i);
				
				if(Character.isDigit(contar)) {
					numero = true;
					
				}
				
				if(Character.isUpperCase(contar)) {
					mayuscula = true;
					
				}
					
			}
			
			if(mayuscula == true && numero == true) {
				
				System.out.println("Contraseña correcta");
			}else {
				
				System.out.println("Contraseña incorrecta, tiene que tener minimo 1 nunmero y una letra mayuscula");
				
			}
	
		}
		
		
	}

}
