package ejProgServi21;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		String[] nombres = new String[5];
		
		
		System.out.println("Introduce un nombre");
		nombres[0] = teclado.next();
		
		for(int i = 1; i < nombres.length; i ++) {
			
			System.out.println("Introduce un nombre");
			nombres[i] = teclado.next();
		}

	}

}
