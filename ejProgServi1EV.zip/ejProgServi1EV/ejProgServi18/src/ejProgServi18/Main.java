package ejProgServi18;

import java.util.Scanner;

public class Main {
	
	public static boolean comprobarContrasenya (String contrasenya) {
		
		boolean entra = false;
		boolean caracteres = false;
		boolean mayuscula = false;
		boolean numero = false;
		char contar;
		
		if (contrasenya.length() >= 5) { //si la longitud de la contraseña es mayor o igual a 5
			
			caracteres = true;
			
			
		
			for (int i = 0; i < contrasenya.length(); i++) { //bucle para verificar si hay numero y mayuscula
				
				contar = contrasenya.charAt(i);
				
				if(Character.isDigit(contar)) {
					numero = true;
					
				}
				
				if(Character.isUpperCase(contar)) {
					mayuscula = true;
					
				}
					
			}
			
			if(caracteres == true && mayuscula == true && numero == true) {
				
				entra = true;
			}
	
		}
		
		return entra;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String contr;
		

		Scanner teclado = new Scanner (System.in);
		System.out.println("Introduce una contraeña con estas caracteristicas: minimo 5 carácteres, 1 número y 1 letra mayúscula ");
		contr = teclado.next();
		
		boolean entra = comprobarContrasenya(contr);
		
		System.out.println(entra);
		
		while(!entra) {
			
			System.out.println("Error. Tiene que cumplir con los requesitos demandados: Minimo 5 carácteres, 1 número y 1 letra");
			System.out.println("Introduce otra contraseña");
			contr = teclado.next();
			entra = comprobarContrasenya(contr);
		}
		
		System.out.println("Contraseña Válida");
		
		
	
			
			
			
			
			
		
		
		

	}

}
