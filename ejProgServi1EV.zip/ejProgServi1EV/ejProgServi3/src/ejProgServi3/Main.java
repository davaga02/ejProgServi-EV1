package ejProgServi3;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce un primer numero");
		int num1 = teclado.nextInt();
		System.out.println("Introduce un segundo numero");
		int num2 = teclado.nextInt();
		
		System.out.println(num1+num2);
	}

}
