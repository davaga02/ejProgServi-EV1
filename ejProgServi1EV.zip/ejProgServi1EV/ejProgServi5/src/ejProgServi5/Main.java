package ejProgServi5;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1;
		int num2;
		
		Scanner teclado = new Scanner(System.in);
		
		do {

			System.out.println("Introduce un primer numero");
			num1 = teclado.nextInt();
			System.out.println("Introduce un segundo numero");
			num2 = teclado.nextInt();
			
		}while(num1 != num2);
		
		System.out.println("Fin. Son iguales");
		
		

	}

}
