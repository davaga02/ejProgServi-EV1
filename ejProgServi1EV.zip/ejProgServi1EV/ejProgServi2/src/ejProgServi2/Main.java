package ejProgServi2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce tu nombre");
		String nombre= teclado.next();
		
		System.out.println("Hola "+ nombre);
	}

}
