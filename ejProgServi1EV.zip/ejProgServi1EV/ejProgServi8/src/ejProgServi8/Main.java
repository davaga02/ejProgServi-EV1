package ejProgServi8;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce un numero del 1 al 12");
		int num = teclado.nextInt();
		
		if(num >=1 && num <= 12) {
			
			if(num == 1) {
				
				System.out.println("Enero");
			}
			if(num == 2) {
				
				System.out.println("Febrero");
			}
			if(num == 3) {
				
				System.out.println("Marzo");
			}
			if(num == 4) {
				
				System.out.println("Abril");
			}
			if(num == 5) {
				
				System.out.println("Mayo");
			}
			if(num == 6) {
				
				System.out.println("Junio");
			}
			if(num == 7) {
				
				System.out.println("Julio");
			}
			if(num == 8) {
				
				System.out.println("Agosto");
			}
			if(num == 9) {
				
				System.out.println("Septiembre");
			}
			if(num == 10) {
				
				System.out.println("Octube");
			}
			if(num == 11) {
				
				System.out.println("Noviembre");
			}
			if(num == 12) {
				
				System.out.println("Diciembre");
			}
			
		}else {
			System.out.println("Error el numero tiene que ser entre el 1 y el 12");
		}

	}

}
