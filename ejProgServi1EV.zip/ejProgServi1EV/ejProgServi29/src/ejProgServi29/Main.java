package ejProgServi29;

import java.util.ArrayList;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vehiculo v1 = new Vehiculo("Coche", "Mercedes" , "Rojo");
		Vehiculo v2 = new Vehiculo("Moto", "BMW" , "Negro");
		Vehiculo v3 = new Vehiculo("Coche", "Seat" , "Gris");
		
		ArrayList<Vehiculo> vehiculos = new ArrayList<Vehiculo>();
		
		vehiculos.add(v1);
		vehiculos.add(v2);
		vehiculos.add(v3);
		
	
	}

}
