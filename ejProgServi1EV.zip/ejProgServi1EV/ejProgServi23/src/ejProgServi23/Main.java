package ejProgServi23;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		boolean entrar = false;
		int i = 0;
		
		ArrayList<String> nombres = new ArrayList<String>();
		
		do {
			
			System.out.println("Introduce un nombre");
			String nombre = teclado.next();
			
			
			if (nombre.equals("0")) {
				entrar = true;
				
			}else {
				
				nombres.add(nombre);
			}
			
			
		}while(!entrar);
		
		
			
			for (String nombre : nombres) {
				
				System.out.println("Nombre " + i + " " + nombre);
				i++;
			}
			
	}

}


