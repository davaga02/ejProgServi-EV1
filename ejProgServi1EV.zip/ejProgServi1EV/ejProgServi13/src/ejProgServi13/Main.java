package ejProgServi13;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce una temperatura en grados centígrados");
		int temperatura = teclado.nextInt();
		
		double gradosFahrenheit = (temperatura * 9/5) + 32;
		
		System.out.println(temperatura + " son " + gradosFahrenheit );

	}

}
