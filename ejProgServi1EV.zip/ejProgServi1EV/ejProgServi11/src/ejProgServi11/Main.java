package ejProgServi11;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduce el numero de tu DNI");
		int dni = teclado.nextInt();
		
		char[] letraDni = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
		
		int resto = dni%23;
		char letra = letraDni[resto];
		
		System.out.println(dni + " " + letra);

	}

}
