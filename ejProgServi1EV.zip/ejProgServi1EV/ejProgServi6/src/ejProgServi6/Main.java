package ejProgServi6;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num = 0;
		
		Scanner teclado = new Scanner(System.in);
		
		for(int i = 0; i < 5; i ++) {
			System.out.println("Introduce un numero ");
			
			num = num + teclado.nextInt();
			
		}
		
		System.out.println(num);

	}

}
