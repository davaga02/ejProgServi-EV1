package ejProgServi26;

import java.util.Scanner;

public class Main {
	
	public static String notas (int nota) {
		
		String resultado = " ";
		if (nota >= 0 && nota <= 4) {
			resultado = "suspenso";
		}
		if (nota == 5 || nota == 6) {
			resultado = "aprobado";
		}
		if (nota == 7 || nota == 8) {
			resultado = "notable";
		}
		if (nota == 9) {
			resultado = "sobresaliente";
		}
		if (nota == 10) {
			resultado = "matrícula";
		}
		
		return resultado;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int nota = 0;
		Scanner teclado = new Scanner(System.in);
		
		for(int i = 0; i < 10; i++) {
			
			if(nota >= 0 && nota <= 10) {
				
				System.out.println("Introduce una nota ");
				nota = teclado.nextInt();
				String resultadoNota = notas(nota);
				
				System.out.println(resultadoNota);
			}

		}

	}
}