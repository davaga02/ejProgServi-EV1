package ejProgServi28;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vehiculo v1 = new Vehiculo("Coche", "Mercedes" , "Rojo");
		Vehiculo v2 = new Vehiculo("Moto", "BMW" , "Negro");
		Vehiculo v3 = new Vehiculo("Coche", "Seat" , "Gris");
		
		System.out.println(v1.toString() + " " + v2.toString() + " " + v3.toString());

	}

}
