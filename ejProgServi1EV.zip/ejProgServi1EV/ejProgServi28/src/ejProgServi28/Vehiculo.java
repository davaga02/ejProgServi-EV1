package ejProgServi28;

public class Vehiculo {
	
	private String tipo;
    private String marca;
    private String color;
    
    public Vehiculo(String tipo, String marca, String color) {
        this.tipo = tipo;
        this.marca = marca;
        this.color = color;
    }

	@Override
	public String toString() {
		return "Vehiculo [tipo=" + tipo + ", marca=" + marca + ", modelo=" + color + "]";
	}
    
    

}
