package ejProgServi12;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int nota = 0;
		int contSusp = 0;
		int contAprob = 0;
		int contNotable = 0;
		int contSobr = 0;
		int contMatricula = 0;
		
		Scanner teclado = new Scanner(System.in);
		
		for(int i = 0; i < 10; i++) {
			
			if(nota >= 0 && nota <= 10) {
				
				System.out.println("Introduce una nota ");
				nota = teclado.nextInt();
				
				switch(nota) {
				case 0:
					contSusp++;
					break;
				case 1:
					contSusp++;
					break;
				case 2:
					contSusp++;
					break;
				case 3:
					contSusp++;
					break;
				case 4:
					contSusp++;
					break;
				case 5:
					contAprob++;
					break;
				case 6:
					contAprob++;
					break;
				case 7:
					contNotable++;
					break;
				case 8:
					contNotable++;
					break;
				case 9:
					contSobr++;
					break;
				case 10:
					contMatricula++;
					break;
				}
			}else {
				
				System.out.println("Error. Solo notas entre el 0 y el 10");
			}
			
		}
		
		System.out.println("Suspensos "+ contSusp + " Aprobados "+ contAprob + " Notables " + contNotable + " Sobresalientes " + contSobr + " Matriculas " + contMatricula);

	}

}
